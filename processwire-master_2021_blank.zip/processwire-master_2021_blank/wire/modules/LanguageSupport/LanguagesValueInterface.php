<?php namespace ProcessWire;

/**
 * Interface for multi-language fields
 *
 * ProcessWire 3.x, Copyright 2016 by Ryan Cramer
 * https://processwire.com
 * 
 * Moved to /wire/core/Interfaces.php
 *
 */



