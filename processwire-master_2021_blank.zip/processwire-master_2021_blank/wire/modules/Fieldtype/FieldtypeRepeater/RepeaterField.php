<?php namespace ProcessWire;

class RepeaterField extends Field {
	// example of custom class for Field object (not yet put to use in this case)
}